//
//  BeaconDetailsViewController.m
//  BeaconPoc
//
//  Created by Aman Gupta on 10/06/16.
//  Copyright © 2016 Aman Gupta. All rights reserved.
//

#import "BeaconDetailsViewController.h"
#import "BeaconCtrlManager.h"
#import <BeaconCtrl/BCLBeacon.h>
#import "BeaconDetailsTableViewCell.h"
@interface BeaconDetailsViewController () {
    NSMutableArray *listOfBeacons;
}

@end

@implementation BeaconDetailsViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
    listOfBeacons = [[NSMutableArray alloc] initWithCapacity:0];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(beaconListChanged:) name:@"sortedBeaconsList" object:nil];
    
}

- (void)beaconListChanged:(NSNotification *)notification
{
    NSSet *beaconList = notification.object;
    
    [listOfBeacons removeAllObjects];
    
    if(beaconList.count>0)
    {
        
        listOfBeacons = [[beaconList allObjects] mutableCopy];
        [self reloadTableViewData];
    }
    NSLog(@"notification %@", beaconList);
    
}

-(void)viewWillAppear:(BOOL)animated
{
//        NSTimer* timer = [NSTimer scheduledTimerWithTimeInterval:2
//                                                          target:self selector:@selector(reloadTableViewData)
//                                                        userInfo:nil repeats:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(listOfBeacons.count>0)
    {
        return (listOfBeacons.count);
    }
    else
    {
        return 1;
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    BeaconDetailsTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"BeaconDetailsCell" forIndexPath:indexPath];
    if(listOfBeacons.count>0)
    {
        
        BCLBeacon *beacon = [listOfBeacons objectAtIndex:indexPath.row];
        if(beacon.name==nil)
        {
            cell.beaconNameLabel.text = beacon.proximityUUID.UUIDString;
        }
        else
        {
            cell.beaconNameLabel.text = beacon.name;
        }
        double beaconDistanceInDouble =beacon.estimatedDistance;
        NSNumber *beaconDistance = [NSNumber numberWithDouble:beaconDistanceInDouble];
        cell.beaconDistanceLabel.text = [NSString stringWithFormat:@"Distance: %.2f m", [[beaconDistance stringValue] floatValue]];
        
    }
    else{
        cell.beaconNameLabel.text =@"No beacon in range";
        cell.beaconDistanceLabel.text =@"";
        
    }
    return cell;
}
-(void)openCamera
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])  {
        UIViewController *vc = [[[[UIApplication sharedApplication] delegate] window] rootViewController];
        [vc presentViewController:picker animated:YES completion:nil];
    }
}

-(void)openCalendar
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"calshow://"]];
    
}
-(void)dwellTime
{
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"Hi" message:@"you are in range" preferredStyle:UIAlertControllerStyleAlert];
    UIViewController *vc = [[[[UIApplication sharedApplication] delegate] window] rootViewController];
    UIAlertAction* yesButton = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction * action) {
                                                          [vc dismissViewControllerAnimated:YES completion:nil];
                                                      }];
    [alert addAction:yesButton];
    [vc presentViewController:alert animated:YES completion:nil];
}
-(void)reloadTableViewData
{
    [[self tableView]reloadData];
    
}
@end
