//
//  BeaconDetailsViewController.h
//  BeaconPoc
//
//  Created by Aman Gupta on 22/06/16.
//  Copyright © 2016 Aman Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BeaconDetailsViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, UINavigationControllerDelegate, UIImagePickerControllerDelegate>
@property (strong, nonatomic) IBOutlet UITableView *tableView;
-(void)openCamera;
-(void)openCalendar;
-(void)dwellTime;
@end
