//
//  BeaconDetailsTableViewCell.m
//  BeaconPoc
//
//  Created by Aman Gupta on 22/06/16.
//  Copyright © 2016 Aman Gupta. All rights reserved.
//

#import "BeaconDetailsTableViewCell.h"

@implementation BeaconDetailsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
