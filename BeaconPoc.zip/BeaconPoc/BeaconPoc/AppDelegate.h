//
//  AppDelegate.h
//  BeaconPoc
//
//  Created by Aman Gupta on 10/06/16.
//  Copyright © 2016 Aman Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSString * const BCLApplicationDidRegisterForRemoteNotificationsNotification;
extern NSString * const BCLApplicationDidFailToRegisterForRemoteNotificationsNotification;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic) BOOL isRemoteNotificationSetupReady;

@property (nonatomic) BOOL shouldVerifySystemSettings;
@property (nonatomic, strong) NSSet *beaconsCopy;

@end

